//	A simple test function shared by the various test programs inside this directory (rss, atom, collada, svg etc.)
package tests
